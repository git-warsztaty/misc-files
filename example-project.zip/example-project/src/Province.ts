import { Culture } from "./Culture";

export class Province {
    public readonly turn: number;
    public readonly name: string;
    private readonly population: string;
    public readonly farms: number;
    public readonly resources: number;
    public readonly culture: Culture;
    public readonly production: string;
    public readonly soldiers: string;
    public readonly fort: string;

    constructor(
        turn: number,
        name: string,
        population: string,
        culture: Culture,
        production: string,
        soldiers: string,
        fort: string
    ) {
        this.turn = turn;
        this.name = name;
        this.population = population;
        const farmsWithResources = this.parsePopulation(population);
        this.farms = farmsWithResources.farms;
        this.resources = farmsWithResources.resources;
        this.culture = culture;
        this.production = production;
        this.soldiers = soldiers;
        this.fort = fort;
    }

    getPopulation() {
        return this.population;
    }

    private parsePopulation(population: string) {

        let rest: string = population;
        let resources = 0;

        while (true) {
            // TODO: charCodeAt() should get a length of 'rest'
            let lastChar = rest[rest.length - 1];
            if (lastChar.charCodeAt(0) === 176) {
                rest = rest.substring(0, rest.length - 1);
                resources++;
            } else {
                break;
            }
        }

        return {
            farms: parseInt(rest),
            resources: resources
        };
    }
}
