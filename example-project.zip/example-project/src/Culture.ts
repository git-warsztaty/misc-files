export enum Culture {
    Primitive = "pri",
    Developed = "dev",
    Advanded = "adv"
}
