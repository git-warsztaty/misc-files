"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Province = /** @class */ (function () {
    function Province(turn, name, population, culture, production, soldiers, fort) {
        this.turn = turn;
        this.name = name;
        this.population = population;
        var farmsWithResources = this.parsePopulation(population);
        this.farms = farmsWithResources.farms;
        this.resources = farmsWithResources.resources;
        this.culture = culture;
        this.production = production;
        this.soldiers = soldiers;
        this.fort = fort;
    }
    Province.prototype.getPopulation = function () {
        return this.population;
    };
    Province.prototype.parsePopulation = function (population) {
        var rest = population;
        var resources = 0;
        while (true) {
            // TODO: charCodeAt() should get a length of 'rest'
            var lastChar = rest[rest.length - 1];
            if (lastChar.charCodeAt(0) === 176) {
                rest = rest.substring(0, rest.length - 1);
                resources++;
            }
            else {
                break;
            }
        }
        return {
            farms: parseInt(rest),
            resources: resources
        };
    };
    return Province;
}());
exports.Province = Province;
//# sourceMappingURL=Province.js.map