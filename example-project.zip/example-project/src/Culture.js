"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Culture;
(function (Culture) {
    Culture["Primitive"] = "pri";
    Culture["Developed"] = "dev";
    Culture["Advanded"] = "adv";
})(Culture = exports.Culture || (exports.Culture = {}));
//# sourceMappingURL=Culture.js.map