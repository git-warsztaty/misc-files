import { Greeter } from "./globals";
import { ProvinceOwnership } from "./provinceOwnership";
import { Provinces } from "./provinces";
import { Province } from "./Province";
import { Culture } from "./Culture";

export class HistoryChecker {

    private provinceOwnership: ProvinceOwnership;

    constructor(provinceOwnership: ProvinceOwnership) {
        this.provinceOwnership = provinceOwnership;
    }

    public checkProvinces() {
        let provinces = Provinces.GetProvinces();
        for (var i = 0; i < provinces.length; i++) {
            var provinceName = provinces[i];

            if (this.provinceOwnership.getConqueredProvinces().includes(provinceName)) {
                continue;
            }

            this.checkHistory(Greeter.provincesHistory[provinceName]);
        }

        // TODO: refactor alertsToShow
        if (this.alertsToShow.length) {
            var message = this.alertsToShow.join(", ");
            console.log(message);
            alert(message);
            this.alertsToShow = [];
        }
    }

    private alertsToShow: string[] = [];

    public reset() {
        this.alertsToShow = [];
    }

    private checkHistory(history: Province[]) {
        if (history.length === 0) {
            return;
        }

        // population 3 is longer than x (5?) => developing
        // -start from last one
        const last = history[history.length - 1];
        const lastSoldiersCount = last.soldiers;

        if (last.farms === 3 && last.resources === 0 && last.culture === Culture.Primitive) {
            let counter = 0;
            for (var i = history.length - 2; i > -1; i--) {
                const current = history[i];
                if (current.farms === 3 && last.resources === 0 && lastSoldiersCount <= current.soldiers) {
                    counter++;
                }
            }

            if (counter > 5) {
                this.alertsToShow.push(last.name + " is developing");
            }
        }
    }
}
