"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Production;
(function (Production) {
    Production["Soldier"] = "Soldier ";
    Production["Gold"] = "Gold";
    Production["Farm"] = "Farm";
    Production["Culture"] = "Culture";
    Production["Fort"] = "Fort";
    Production["Diplomats"] = "Diplomats";
})(Production = exports.Production || (exports.Production = {}));
//# sourceMappingURL=Production.js.map