﻿using System;

namespace ConquerorParser
{
    class Program
    {
        static void Main(string[] args)
        {
            ProvinceNameParser.Run();
        }
    }
}
