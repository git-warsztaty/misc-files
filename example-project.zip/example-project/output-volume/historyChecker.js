"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const globals_1 = require("./globals");
const provinceOwnership_1 = require("./provinceOwnership");
const provinces_1 = require("./provinces");
class HistoryChecker {
    static checkProvinces() {
        let provinces = provinces_1.Provinces.GetProvinces();
        for (var i = 0; i < provinces.length; i++) {
            var provinceName = provinces[i];
            if (provinceOwnership_1.ProvinceOwnership.conqueredProvinces.includes(provinceName)) {
                continue;
            }
            HistoryChecker.checkHistory(globals_1.Greeter.provincesHistory[provinceName]);
        }
        // TODO: refactor alertsToShow
        if (HistoryChecker.alertsToShow.length) {
            var message = HistoryChecker.alertsToShow.join(", ");
            console.log(message);
            alert(message);
            HistoryChecker.alertsToShow = [];
        }
    }
    static reset() {
        this.alertsToShow = [];
    }
    static checkHistory(history) {
        if (history.length === 0) {
            return;
        }
        // population 3 is longer than x (5?) => developing
        // -start from last one
        var last = history[history.length - 1];
        var lastSoldiersCount = last.soldiers;
        if (last.population === "3" && last.culture === "pri") {
            var counter = 0;
            for (var i = history.length - 2; i > -1; i--) {
                var current = history[i];
                if (current.population === "3" && lastSoldiersCount <= current.soldiers) {
                    counter++;
                }
            }
            if (counter > 5) {
                HistoryChecker.alertsToShow.push(last.name + " is developing");
            }
        }
    }
}
exports.HistoryChecker = HistoryChecker;
HistoryChecker.alertsToShow = [];
