"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const provinces_1 = require("./provinces");
class ProvinceOwnership {
    static updateOwnedProvinces() {
        function createId(prefix, province) {
            return prefix + province.toLowerCase();
        }
        let provinces = provinces_1.Provinces.GetProvinces();
        for (var i = 0; i < provinces.length; i++) {
            let provinceName = provinces[i];
            if (ProvinceOwnership.conqueredProvinces.includes(provinceName)) {
                continue;
            }
            // TODO: prefetch it
            var a = document.getElementsByClassName("svgMap")[0];
            var svgDoc = a.contentDocument;
            var map = svgDoc.getElementById(createId("field_", provinceName));
            if (map == null) {
                continue;
            }
            var color = map.getAttribute("fill");
            var playerColors = [
                '#ff3131', '#009c00', '#3131ff', '#ffce00', '#636300',
                '#63319c', '#ce63ce', '#ce9c63', '#006363', '#319c9c'
            ];
            if (playerColors.includes(color)) {
                ProvinceOwnership.conqueredProvinces.push(provinceName);
                console.log("conquered: ", provinceName);
            }
        }
    }
}
exports.ProvinceOwnership = ProvinceOwnership;
