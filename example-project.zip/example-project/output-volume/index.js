"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jquery_1 = __importDefault(require("jquery"));
const globals_1 = require("./globals");
const provinces_1 = require("./provinces");
const provinceOwnership_1 = require("./provinceOwnership");
const provincesParser_1 = require("./provincesParser");
const historyChecker_1 = require("./historyChecker");
const buildingChecker_1 = require("./buildingChecker");
const hud_1 = require("./hud");
class ConquerorSpy {
    static Start() {
        console.log('running conqueror-browser-spy');
        ConquerorSpy.cleanAllValues();
        var refrestTurnInterval;
        clearInterval(refrestTurnInterval);
        refrestTurnInterval = setInterval(ConquerorSpy.refreshTurn, 500);
        var refreshNameInterval;
        clearInterval(refreshNameInterval);
        refreshNameInterval = setInterval(ConquerorSpy.refreshName, 200);
        var toolVersion = '1.0';
        console.log("tool version: " + toolVersion);
    }
    static refreshTurn() {
        var turn = globals_1.Greeter.getTurn();
        if (isNaN(turn)) {
            console.log('turn is nan');
            return;
        }
        if (turn !== ConquerorSpy.lastTurn) {
            if (turn === 1) {
                ConquerorSpy.cleanAllValues();
            }
            ConquerorSpy.lastTurn = turn;
            console.log("New turn: ", ConquerorSpy.lastTurn);
            ConquerorSpy.provinceParser.updateProvinces();
            historyChecker_1.HistoryChecker.checkProvinces();
            provinceOwnership_1.ProvinceOwnership.updateOwnedProvinces();
            ConquerorSpy.buildingChecker.checkBuildingProvinces();
            console.log("refreshTurn() finished");
        }
    }
    static cleanAllValues() {
        //lastCountry = "";
        provinceOwnership_1.ProvinceOwnership.conqueredProvinces = [];
        globals_1.Greeter.provincesHistory = {};
        let provinces = provinces_1.Provinces.GetProvinces();
        for (var i = 0; i < provinces.length; i++) {
            var provinceName = provinces[i];
            globals_1.Greeter.provincesHistory[provinceName] = [];
        }
        historyChecker_1.HistoryChecker.reset();
        ConquerorSpy.buildingChecker.reset();
    }
    static getCountry() {
        var countrySelector = '#gameWrapper > div > div.area.areaR > div.view.headerView.conqFieldTools.fogOfWar0 > div > div.fieldHeaderWrapper > div.fieldHeader > span';
        var text = jquery_1.default(countrySelector).text().toLowerCase();
        function removeDiacritics(str) { return str.normalize('NFD').replace(/[\u0300-\u036f]/g, ""); }
        text = removeDiacritics(text);
        if (text === "ile de france") {
            text = "iledefrance";
        }
        return text;
    }
    static refreshName() {
        var country = ConquerorSpy.getCountry();
        if (country !== ConquerorSpy.lastCountry) {
            ConquerorSpy.lastCountry = country;
            ConquerorSpy.hud.refreshHudHistory(country);
        }
    }
}
exports.ConquerorSpy = ConquerorSpy;
ConquerorSpy.lastTurn = NaN;
ConquerorSpy.provinceParser = new provincesParser_1.ProvinceParser();
ConquerorSpy.buildingChecker = new buildingChecker_1.BuildingChecker();
ConquerorSpy.hud = new hud_1.Hud();
ConquerorSpy.lastCountry = "";
ConquerorSpy.Start();
