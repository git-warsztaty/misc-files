"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const globals_1 = require("./globals");
const provinces_1 = require("./provinces");
class ProvinceParser {
    // Get details of one province.
    // - (without turn)
    getCountryDetails(countryName) {
        function createId(prefix, province) {
            return prefix + province.toLowerCase();
        }
        // TODO: prefetch it
        let a = document.getElementsByClassName("svgMap")[0];
        var svgDoc = a.contentDocument;
        var populationItem = svgDoc.getElementById(createId("pop_", countryName));
        if (populationItem === null) {
            return null;
        }
        // fog of war
        if (populationItem.getAttribute("visibility") === "hidden") {
            return null;
        }
        var culture = populationItem.className.animVal;
        if (culture === "") {
            culture = 'pri';
        }
        function parseProduction(icon) {
            var production = icon.replace("../common/images/icon_", "").replace(".png", "");
            if (production === "castle_kind") {
                production = "fort";
            }
            // possible values: {
            // "",
            // }
            return production;
        }
        var productionItem = svgDoc.getElementById(createId("prod_", countryName));
        var production = productionItem.getAttribute("xlink:href");
        var isHidden = productionItem.getAttribute("visibility") === "hidden";
        if (isHidden) {
            production = "";
        }
        else {
            production = parseProduction(production);
        }
        var soldierItem = svgDoc.getElementById(createId("info_", countryName));
        var countryDetails = {
            turn: globals_1.Greeter.getTurn(),
            name: countryName,
            population: populationItem.textContent,
            culture: culture,
            production: production,
            soldiers: soldierItem.textContent,
            fort: this.getFort(svgDoc, countryName)
        };
        console.log('province parsed:', countryName);
        return countryDetails;
    }
    getFort(svgDoc, countryName) {
        function createFortId(prefix, province) {
            return prefix + province.toLowerCase() + "_0";
        }
        var fortItem = svgDoc.getElementById(createFortId("fort_", countryName));
        if (fortItem !== null) {
            return "fort";
        }
        else {
            var keepItem = svgDoc.getElementById(createFortId("keep_", countryName));
            if (keepItem !== null) {
                return "keep";
            }
            else {
                return "";
            }
        }
    }
    // TODO: animVal vs baseVal?
    //svgItem.className.animVal
    // #prod_crete
    // < image id = "prod_crete" class="prod" height = "12" width = "12" x = "738.4375" y = "659" xlink:href = "../common/images/icon_unit.png" visibility = "inherit" transform = "translate(242.56000000000006,213.76)" />
    // icon_farm.png, icon_unit.png, gold, culture, castle_kind, diplomat,
    updateProvinces() {
        let provinces = provinces_1.Provinces.GetProvinces();
        for (var i = 0; i < provinces.length; i++) {
            let provinceName = provinces[i];
            var province = this.getCountryDetails(provinceName);
            if (province === null) {
                continue;
            }
            let a = globals_1.Greeter.provincesHistory[provinceName];
            a.push(province);
        }
    }
}
exports.ProvinceParser = ProvinceParser;
