"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jquery_1 = __importDefault(require("jquery"));
const globals_1 = require("./globals");
const provinceOwnership_1 = require("./provinceOwnership");
class Hud {
    initHud() {
        if (jquery_1.default('#hud').length) {
            return;
        }
        var timerWrapperSelector = '#gameWrapper > div > div.area.areaT > div.area.areaTM > div > div > div > div.turnTimer';
        var timerWrapper = jquery_1.default(timerWrapperSelector);
        var hud = jquery_1.default('<div id="hud" style="margin-top: 20px;"></div>');
        timerWrapper.append(hud);
    }
    updateHud(text) {
        this.initHud();
        jquery_1.default('#hud').text(text);
    }
    updateHudHtml(html) {
        this.initHud();
        jquery_1.default('#hud').html(html);
    }
    isTheSameProvinceExceptTurn(first, second) {
        return first.population === second.population
            && first.culture === second.culture
            // && first.production === second.production // this is only our prediction
            && first.soldiers === second.soldiers
            && first.fort === second.fort;
    }
    isHistoryEntryUnique(history, currentIndex) {
        if (currentIndex === 0) {
            return true;
        }
        if (currentIndex === history.length - 1) {
            return true;
        }
        return !this.isTheSameProvinceExceptTurn(history[currentIndex - 1], history[currentIndex])
            || !this.isTheSameProvinceExceptTurn(history[currentIndex], history[currentIndex + 1]);
    }
    refreshHudHistory(countryName) {
        function lineIt(details) {
            var fort = "";
            if (details.fort) {
                fort = "," + details.fort[0];
            }
            return details.turn + ": " + details.population + details.culture + fort + "," + details.soldiers;
        }
        if (provinceOwnership_1.ProvinceOwnership.conqueredProvinces.includes(countryName)) {
            this.updateHud("");
            return;
        }
        var history = globals_1.Greeter.provincesHistory[countryName];
        var lines = [];
        for (var i = history.length - 1; i > -1; i--) {
            if (this.isHistoryEntryUnique(history, i)) {
                lines.push(lineIt(history[i]));
            }
        }
        this.updateHudHtml(lines.join("<br>"));
    }
}
exports.Hud = Hud;
