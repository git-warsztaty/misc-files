"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jquery_1 = __importDefault(require("jquery"));
class Greeter {
    static getTurn() {
        let turnSelector = '#gameWrapper > div > div.area.areaT > div.area.areaTM > div > div > div > div.turnInfo > div > span.turnCount';
        return parseInt(jquery_1.default(turnSelector).text().substring(5));
    }
}
exports.Greeter = Greeter;
Greeter.provincesHistory = {};
